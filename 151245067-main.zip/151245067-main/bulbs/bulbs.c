#include <cs50.h>
#include <stdio.h>
#include <string.h>

const int BITS_IN_BYTE = 8;

void print_bulb(int bit);

int main(void)
{

    // Get user input string
    string binate = get_string ("To Binate: ");

    // Convert string into decimal form
    for (int i = 0, n = strlen (binate); i < n; i++)
    {
        int decimal = (int) binate[i];
        // Place bits from the left on 7
        for (int j = BITS_IN_BYTE - 1; j >= 0; j--)
        {
            // Check last bit with & 1, new line
            int bit = (decimal >> j) & 1;
            print_bulb(bit);
        }
        printf("\n")
    }
}

void print_bulb(int bit)
{
    // Convert bit into emoji unicode
    if (bit == 0)
    {
        // Dark emoji
        printf("\U000026AB");
    }
    else if (bit == 1)
    {
        // Light emoji
        printf("\U0001F7E1");
    }
}

#include <cs50.h>
#include <stdio.h>

void build (int height)
int main(void)
{
    int height;
    do
    {
        height = get_int("height: ");
        // initiate build fnct
        build(int height);
    }
    while (height < 1 || height > 8);
}

void build (int height)
{
    // row int
    for (int i = 0; i < (height + 1); i++)
    {
         // brick int
          for (int j = 1; j < (height + 1); j++)
          if (j <= (height - i))
           {
             printf(" ");
            else
                // print brick
            printf("#");
            }
    }

    // next line
    printf("\n");
    }
}
